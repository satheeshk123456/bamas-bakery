from datetime import datetime, timedelta, timezone

import bcrypt
from fastapi import Depends, Header, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError, jwt

from .config import settings

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="auth/login")

# Both shop admins and customers now authenticate with this backend's own
# JWTs (Firebase Authentication has been removed -- Firebase is kept ONLY
# for FCM push notifications). Because both token kinds are signed with the
# same secret, every token carries a "typ" claim and each dependency below
# accepts only its own kind. Without that, a customer's token would be
# accepted on admin endpoints.
TOKEN_TYPE_ADMIN = "admin"
TOKEN_TYPE_CUSTOMER = "customer"


def verify_password(plain_password: str, hashed_password: str) -> bool:
    if not hashed_password:
        return False
    try:
        return bcrypt.checkpw(plain_password.encode("utf-8"), hashed_password.encode("utf-8"))
    except (ValueError, TypeError):
        # Not a valid bcrypt hash (e.g. ADMIN_PASSWORD_HASH still a
        # placeholder) -- treat as "wrong password", don't 500.
        return False


def hash_password(plain_password: str) -> str:
    return bcrypt.hashpw(plain_password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def create_access_token(subject: str, token_type: str = TOKEN_TYPE_ADMIN) -> str:
    expire = datetime.now(timezone.utc) + timedelta(minutes=settings.jwt_expires_minutes)
    payload = {"sub": subject, "typ": token_type, "exp": expire}
    return jwt.encode(payload, settings.jwt_secret, algorithm="HS256")


def _decode(token: str, expected_type: str) -> str:
    unauthorized = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Invalid or expired session, please log in again.",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, settings.jwt_secret, algorithms=["HS256"])
    except JWTError:
        raise unauthorized
    subject = payload.get("sub")
    # A missing or mismatched "typ" is rejected: an admin token must never
    # satisfy a customer route, and a customer token must never satisfy an
    # admin route.
    if not subject or payload.get("typ") != expected_type:
        raise unauthorized
    return subject


def get_current_customer_uid(authorization: str | None = Header(None)) -> str:
    """Customer identity, from this backend's own JWT (issued by
    /account/register and /account/login)."""
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired session, please log in again.",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return _decode(authorization.split(" ", 1)[1], TOKEN_TYPE_CUSTOMER)


def get_current_admin(token: str = Depends(oauth2_scheme)) -> str:
    """Shop admin identity, from /auth/login."""
    return _decode(token, TOKEN_TYPE_ADMIN)
