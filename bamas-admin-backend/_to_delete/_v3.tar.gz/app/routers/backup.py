import json
from datetime import datetime, timezone

from bson import ObjectId
from fastapi import APIRouter, Depends, Header, HTTPException, status
from fastapi.responses import StreamingResponse

from ..config import settings
from ..mongo_client import get_db
from ..security import get_current_admin

router = APIRouter(prefix="/backup", tags=["backup"])

BACKUP_COLLECTIONS = [
    "menuItems",
    "categories",
    "offers",
    "shopSettings",
    "orders",
    "users",
    "reviews",
    "enquiries",
]


def _json_safe(value):
    """Mongo hands back ObjectId and datetime values that json.dumps
    can't serialize directly -- convert them recursively. Note: image
    fields are stored as plain S3 KEYS (not presigned URLs) in Mongo, so
    they come through here as-is, which is what we want for a backup --
    a presigned URL would just expire."""
    if isinstance(value, ObjectId):
        return str(value)
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, dict):
        return {k: _json_safe(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_json_safe(v) for v in value]
    return value


def _build_backup_payload() -> dict:
    db = get_db()
    collections = {}
    for name in BACKUP_COLLECTIONS:
        docs = list(db[name].find())
        collections[name] = {str(d["_id"]): _json_safe({k: v for k, v in d.items() if k != "_id"}) for d in docs}
    return {
        "generatedAt": datetime.now(timezone.utc).isoformat(),
        "shop": "Bama's Burger Box",
        "collections": collections,
    }


def _as_download(payload: dict) -> StreamingResponse:
    body = json.dumps(payload, indent=2, ensure_ascii=False)
    filename = f"bamas-backup-{datetime.now(timezone.utc).strftime('%Y-%m-%d')}.json"
    return StreamingResponse(
        iter([body]),
        media_type="application/json",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.get("/full")
def download_backup_admin(admin: str = Depends(get_current_admin)):
    """Manual full-data backup -- the "Download full backup now" button
    in the admin app. Requires a normal logged-in admin session."""
    return _as_download(_build_backup_payload())


def _verify_backup_key(x_backup_key: str | None = Header(None)):
    """A SEPARATE, narrower credential from the real admin login -- used
    only by the weekly automated backup job. If this key ever leaked it
    only grants read access to a data export -- no login, no writes."""
    if not settings.backup_secret_key:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Server is missing BACKUP_SECRET_KEY.",
        )
    if not x_backup_key or x_backup_key != settings.backup_secret_key:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Invalid backup key.")


@router.get("/full/scheduled", dependencies=[Depends(_verify_backup_key)])
def download_backup_scheduled():
    """Same export as /backup/full, but authenticated with the
    long-lived X-Backup-Key header -- the weekly automated backup task
    calls this one, with nobody logged in."""
    return _as_download(_build_backup_payload())
