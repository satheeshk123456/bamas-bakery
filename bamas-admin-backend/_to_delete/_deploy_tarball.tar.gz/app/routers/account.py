from datetime import datetime, timezone

import httpx
from fastapi import APIRouter, Depends, HTTPException
from firebase_admin import auth as fb_auth

from ..config import settings
from ..firebase_client import get_firebase_app
from ..mongo_client import get_db
from ..mongo_utils import serialize
from ..models import (
    AuthTokenResponse,
    CustomerLoginRequest,
    CustomerRegisterRequest,
    ForgotPasswordRequest,
)
from ..security import get_current_customer_uid

# Everything the bamas customer app needs for accounts: register, login,
# forgot-password, "my profile", "my orders". Identity (register/login/
# password checks) is still Firebase Authentication -- only the profile
# DATA (users/{uid} -> name/phone/email) has moved to MongoDB, keyed by
# the same Firebase uid.
router = APIRouter(prefix="/account", tags=["account"])

IDENTITY_TOOLKIT_BASE = "https://identitytoolkit.googleapis.com/v1/accounts"


def _require_web_api_key():
    if not settings.firebase_web_api_key:
        raise HTTPException(
            status_code=500,
            detail=(
                "Server is missing FIREBASE_WEB_API_KEY. Set it in the "
                "backend's environment variables (Firebase console -> "
                "Project settings -> General -> Web API Key)."
            ),
        )


@router.post("/register", response_model=AuthTokenResponse)
async def register(body: CustomerRegisterRequest):
    """Creates the Firebase Auth user AND the Mongo `users` profile doc,
    server-side -- the app never talks to Firebase Auth directly to sign
    someone up."""
    get_firebase_app()
    try:
        user = fb_auth.create_user(
            email=body.email.strip(),
            password=body.password,
            display_name=body.name.strip(),
        )
    except fb_auth.EmailAlreadyExistsError:
        raise HTTPException(status_code=409, detail="An account already exists for that email.")
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    db = get_db()
    db.users.replace_one(
        {"_id": user.uid},
        {
            "name": body.name.strip(),
            "phone": body.phone.strip(),
            "email": body.email.strip(),
            "createdAt": datetime.now(timezone.utc),
        },
        upsert=True,
    )

    token = fb_auth.create_custom_token(user.uid).decode("utf-8")
    return AuthTokenResponse(uid=user.uid, customToken=token)


@router.post("/login", response_model=AuthTokenResponse)
async def login(body: CustomerLoginRequest):
    """Checks the password via Google's Identity Toolkit REST API (the
    Admin SDK has no "verify this password" call), then mints a Firebase
    custom token for that uid so the app can establish a normal session."""
    _require_web_api_key()
    async with httpx.AsyncClient(timeout=10) as client:
        resp = await client.post(
            f"{IDENTITY_TOOLKIT_BASE}:signInWithPassword",
            params={"key": settings.firebase_web_api_key},
            json={"email": body.email.strip(), "password": body.password, "returnSecureToken": True},
        )
    if resp.status_code != 200:
        raise HTTPException(status_code=401, detail="Incorrect email or password.")

    uid = resp.json()["localId"]
    get_firebase_app()
    token = fb_auth.create_custom_token(uid).decode("utf-8")
    return AuthTokenResponse(uid=uid, customToken=token)


@router.post("/forgot-password")
async def forgot_password(body: ForgotPasswordRequest):
    _require_web_api_key()
    async with httpx.AsyncClient(timeout=10) as client:
        await client.post(
            f"{IDENTITY_TOOLKIT_BASE}:sendOobCode",
            params={"key": settings.firebase_web_api_key},
            json={"requestType": "PASSWORD_RESET", "email": body.email.strip()},
        )
    return {"sent": True}


@router.get("/me")
def get_my_profile(uid: str = Depends(get_current_customer_uid)):
    db = get_db()
    doc = db.users.find_one({"_id": uid})
    if doc is None:
        # Self-heal instead of 404ing forever: the caller has a valid
        # Firebase session token, so the Auth user genuinely exists --
        # but their Mongo profile doc is missing (e.g. an account from
        # before this endpoint wrote one, or created directly in the
        # Firebase console). Build a minimal profile from the Auth
        # record so the Account screen always has something to show.
        try:
            auth_user = fb_auth.get_user(uid)
        except Exception:
            auth_user = None
        doc = {
            "name": (getattr(auth_user, "display_name", None) or "") if auth_user else "",
            "phone": "",
            "email": (getattr(auth_user, "email", None) or "") if auth_user else "",
            "createdAt": datetime.now(timezone.utc),
        }
        db.users.update_one({"_id": uid}, {"$set": doc}, upsert=True)
    data = dict(doc)
    data.pop("_id", None)
    data["uid"] = uid
    created = data.get("createdAt")
    if created is not None and hasattr(created, "isoformat"):
        data["createdAt"] = created.isoformat()
    return data


@router.get("/orders")
def get_my_orders(uid: str = Depends(get_current_customer_uid), limit: int = 50):
    db = get_db()
    docs = db.orders.find({"userId": uid}).sort("createdAt", -1).limit(limit)
    return [serialize(d) for d in docs]
