from fastapi import APIRouter, Depends, File, HTTPException, UploadFile

from ..mongo_client import get_db
from ..mongo_utils import oid, serialize
from ..image_utils import ITEM_IMAGE_MAX_BYTES, presigned_url, upload_image
from ..models import CategoryCreate, MenuItemCreate, MenuItemUpdate
from ..security import get_current_admin

# Reads are PUBLIC (the bamas customer app's menu screen calls these
# directly, no login -- same as the old Firestore rule
# `allow read: if true`). Writes need an admin login, applied per-route
# below instead of at the router level.
router = APIRouter(prefix="/menu", tags=["menu"])


def _with_image(doc) -> dict:
    """Serializes a doc and turns its stored S3 key (if any) into a
    fresh, short-lived signed URL the app can load directly."""
    data = serialize(doc)
    if data is not None and data.get("imageUrl"):
        data["imageUrl"] = presigned_url(data["imageUrl"])
    return data


@router.get("/categories")
def list_categories():
    db = get_db()
    docs = db.categories.find().sort("sortOrder", 1)
    return [_with_image(d) for d in docs]


@router.post("/categories", dependencies=[Depends(get_current_admin)])
def create_category(body: CategoryCreate):
    """Adds a brand-new menu category (e.g. "Beverages", "Desserts")."""
    db = get_db()
    existing_count = db.categories.count_documents({})
    data = {
        "name": body.name.strip(),
        "imageUrl": body.imageUrl or "",
        "sortOrder": body.sortOrder if body.sortOrder is not None else existing_count + 1,
    }
    result = db.categories.insert_one(dict(data))
    data["_id"] = result.inserted_id
    return _with_image(data)


@router.post("/categories/{category_id}/image", dependencies=[Depends(get_current_admin)])
async def upload_category_image(category_id: str, file: UploadFile = File(...)):
    db = get_db()
    _id = oid(category_id)
    if db.categories.find_one({"_id": _id}) is None:
        raise HTTPException(status_code=404, detail="Category not found.")
    key = await upload_image(file, prefix="categories", doc_id=category_id, max_bytes=ITEM_IMAGE_MAX_BYTES)
    db.categories.update_one({"_id": _id}, {"$set": {"imageUrl": key}})
    return {"imageUrl": presigned_url(key)}


@router.get("/items")
def list_items(categoryId: str | None = None):
    db = get_db()
    filt = {"categoryId": categoryId} if categoryId else {}
    return [_with_image(d) for d in db.menuItems.find(filt)]


@router.post("/items", dependencies=[Depends(get_current_admin)])
def create_item(body: MenuItemCreate):
    """Adds a brand-new item -- the admin app's "+" (add) icon. Writes
    into the same `menuItems` collection the customer app's GET
    /menu/items reads, so the item shows up immediately."""
    db = get_db()
    existing_count = db.menuItems.count_documents({})
    data = body.model_dump()
    data["sortOrder"] = existing_count + 1
    result = db.menuItems.insert_one(dict(data))
    data["_id"] = result.inserted_id
    return _with_image(data)


@router.patch("/items/{item_id}", dependencies=[Depends(get_current_admin)])
def update_item(item_id: str, body: MenuItemUpdate):
    """Toggle availability ('sold out'), change price, name, or
    description -- shows up in the customer app immediately."""
    db = get_db()
    _id = oid(item_id)
    doc = db.menuItems.find_one({"_id": _id})
    if doc is None:
        raise HTTPException(status_code=404, detail="Menu item not found.")

    updates = {k: v for k, v in body.model_dump(exclude_unset=True).items() if v is not None}
    if not updates:
        raise HTTPException(status_code=400, detail="No fields to update.")
    db.menuItems.update_one({"_id": _id}, {"$set": updates})
    return _with_image(db.menuItems.find_one({"_id": _id}))


@router.post("/items/{item_id}/image", dependencies=[Depends(get_current_admin)])
async def upload_item_image(item_id: str, file: UploadFile = File(...)):
    db = get_db()
    _id = oid(item_id)
    if db.menuItems.find_one({"_id": _id}) is None:
        raise HTTPException(status_code=404, detail="Menu item not found.")
    key = await upload_image(file, prefix="menu-items", doc_id=item_id, max_bytes=ITEM_IMAGE_MAX_BYTES)
    db.menuItems.update_one({"_id": _id}, {"$set": {"imageUrl": key}})
    return {"imageUrl": presigned_url(key)}
